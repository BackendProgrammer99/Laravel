<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNavbar"
        aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    
    <div class="collapse navbar-collapse" id="mainNavbar">
        <ul class="navbar-nav mr-auto">
            <?php if(Auth::check() && Auth::user()->hasRole('user')): ?>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(url('/home')); ?>">STRONA GŁÓWNA <span
                            class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('reservations.index')); ?>">Rezerwacja sal kinowych</a>
                </li>
            <?php endif; ?>
            <?php if(Auth::check() && Auth::user()->hasAnyRole('worker', 'admin')): ?>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(url('/home')); ?>">STRONA TYTUŁOWA <span
                            class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('customers.index')); ?>">KLIENCI</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('services.index')); ?>">WYNAJEM</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('reservations.index')); ?>">Rezerwacje sal
                        kinowych</a>
                </li>


                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('pricelists.index')); ?>">CENNIK REZERWACJI</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('users.index')); ?>">UŻYTKOWNICY</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">LOGOWANIE</a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">REJESTRACJA</a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('users.edit-profile')); ?>">
                            EDYTUJ PROFIL
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                               document.getElementById('logout-form').submit();">
                            WYLOGUJ
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\Piotr\Desktop\cinema\cinema\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>