<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    
    
    <link href="<?php echo e(url('css/external/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/external/font-awesome-all.min.css')); ?>" type="text/css" rel="stylesheet">
    
    <link href="<?php echo e(url('css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('resources/css/app.css')); ?>" rel="stylesheet">
    
    <?php echo $__env->yieldContent('css-styles'); ?>
</head>

<body>
    
    
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main role="main" class="container padding-top-content">
        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

<script type="text/javascript" src="<?php echo e(url('js/external/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/external/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/external/bootstrap.min.js')); ?>"></script>


<?php if(config('app.env') === 'dev'): ?>
    <script type="text/javascript">
        var d = function(message) {
            console.log(message);
        }
    </script>
<?php else: ?>
    <script type="text/javascript">
        var d = function(message) {}
    </script>
<?php endif; ?>

<script type="text/javascript" src="<?php echo e(url(mix('js/all.min.js'))); ?>"></script>

<?php echo $__env->yieldContent('js-scripts'); ?>

</html>
<?php /**PATH C:\Users\Piotr\Desktop\cinema\cinema\resources\views/layouts/app.blade.php ENDPATH**/ ?>