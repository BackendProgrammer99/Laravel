
<?php if(session('success')): ?>
    <div class="alert alert-success mt-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('warning')): ?>
    <div class="alert alert-warning mt-4">
        <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger mt-4">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Piotr\Desktop\cinema\cinema\resources\views/layouts/alert.blade.php ENDPATH**/ ?>