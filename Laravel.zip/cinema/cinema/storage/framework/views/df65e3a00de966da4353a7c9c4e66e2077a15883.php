<footer class="container border-top text-center mt-3 pt-3 pb-3">
    <p>&copy; Piotr Nawrocki NST INF 30178 PROJEKT REALIZOWANY W RAMACH ZAJĘĆ ZAAWANSOWANYCH APLIKACJI WEBOWYCH
        <?php echo e(now()->year); ?></p>
</footer>
<?php /**PATH C:\Users\Piotr\Desktop\cinema\cinema\resources\views/layouts/footer.blade.php ENDPATH**/ ?>