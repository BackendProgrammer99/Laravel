<?php

namespace Database\Seeders;
use Faker\Factory;
use App\Models\Customer;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CustomersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Factory::create("pl_PL");
        $customers = [
            1 => 'Piotr Nowak',
            2 => 'Alicja Górna',
            3 => 'Piotr Śmieszek',
            4 => 'Patryk Nawrocki',
            5 => 'Karolina Wierzba',
            6 => 'Adam Ciemny',
            7 => 'Paweł Cichy',
            8 => 'Jan Nowak',
            9 => 'Kacper Przybylski',
            10 => 'Michalina Majewska',
        
        ];
        foreach ($customers as $key => $customer) {
            DB::table('customers')->insert([
                // stałe id
                'id' => $key,
                // losowy wyraz
                'name' => $customer,
                'street'=> $faker->streetName,
                'homenr'=> $faker->numberBetween(1,50),
                'postalcode'=> '62-800', 
                'locality'=> 'Kalisz',
                'phonenr'=> '+48 585 485 834',
                // losowa data w zadanym zakresie
                'created_at' => $faker->dateTimeBetween(
                     '-40 days',
                     '-20 days'
                 ),
                 'updated_at' => rand(0, 9) < 5
                    ? null
                    : $faker->dateTimeBetween(
                        '-15 days',
                        '-10 days'
                  ),
                  'deleted_at' => rand(0, 9) < 8
                     ? null
                     : $faker->dateTimeBetween(
                         '-5 days',
                         'now'
                   )
            ]);
        }        
    }
}
