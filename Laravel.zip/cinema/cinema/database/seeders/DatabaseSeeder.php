<?php

namespace Database\Seeders;

use Illuminate\Database\Eloquent\Model;
use Database\Seeders\RolesSeeder;
use Database\Seeders\PermissionsSeeder;
use Database\Seeders\UsersSeeder;
use Database\Seeders\CustomersSeeder;
use Database\Seeders\PricelistsSeeder;
use Database\Seeders\ServicesSeeder;
use Database\Seeders\ReservationsSeeder;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(RolesSeeder::class);
        $this->call(PermissionsSeeder::class);
        $this->call(UsersSeeder::class);
        // Tworzenie migracji i uzupełnienie danych
        // komendą: php artisan migrate:fresh --seed
        $this->call(CustomersSeeder::class);
        $this->call(PricelistsSeeder::class);
        $this->call(ServicesSeeder::class);
        $this->call(ReservationsSeeder::class);
    }
}
