<?php
namespace Database\Seeders;

use App\Models\Reservation;
use Faker\Factory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ReservationsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Factory::create("pl_PL");
        $rangeMax = 1000.0;
        for($i = 0; $i < 50; $i++) {
            DB::table('reservations')->insert([
                // losowy wyraz
                'data'=> $faker->dateTime(
                    '-20 days',
                    null
                ),
                'timefrom' => $faker->time(
                    'H:i:s',
                    rand(36000,75600)
                ),
                'timeto' => $faker->time(
                    'H:i:s',
                    rand(36000,75600)
                ),
                'numberofpeople' => rand(1, 50),
                'endprice' => (rand() % $rangeMax)/100.0,
                'service_id'=> rand(1, 2),
                'customer_id'=>rand(1, 30),
                'created_at' => $faker->dateTimeBetween(
                    '-40 days',
                    '-20 days'
                ),
                'updated_at' => rand(0, 9) < 5
                   ? null
                   : $faker->dateTimeBetween(
                       '-15 days',
                       '-10 days'
                 ),
                 'deleted_at' => rand(0, 9) < 8
                    ? null
                    : $faker->dateTimeBetween(
                        '-5 days',
                        'now'
                  )
            ]);
        }
    }        
}
