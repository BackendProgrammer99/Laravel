<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Permission\Models\Permission;
use Illuminate\Permission\Models\Role;
use Illuminate\Permission\PermissionRegistrar;

class RolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // uruchomienie konkretnego seedera
        // komenda: php artisan db:seed --class=RoleSeeder

        // Reset cached roles and permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        $superadmin = Role::create(['name' => config('permission.roles.worker')]);
        $admin = Role::create(['name' => config('permission.roles.admin')]);
        $user = Role::create(['name' => config('permission.roles.user')]);
        
    }
}
