<?php
namespace Database\Seeders;
use App\Models\Service;
use Faker\Factory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ServicesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Factory::create("pl_PL");
        $services = [
            1 => 'sala kinowa - film Spider Man',
            2 => 'Sala kinowa - film X-men ',
            3 => 'sala kinowa - film Listy do M',
            4 => 'Sala kinowa - film Diuna ',
        ];
            foreach ($services as $key => $service) {
                DB::table('services')->insert([
                    // stałe id
                    'id' => $key,
                    // losowy wyraz
                    'name' => $service,
                    'pricelist_id' => rand(1, 50),
                    'created_at' => $faker->dateTimeBetween(
                        '-40 days',
                        '-20 days'
                    ),
                    'updated_at' => rand(0, 9) < 5
                    ? null
                    : $faker->dateTimeBetween(
                        '-15 days',
                        '-10 days'
                    ),
                    'deleted_at' => rand(0, 9) < 8
                        ? null
                        : $faker->dateTimeBetween(
                            '-5 days',
                            'now'
                    )
                ]);
            }
        
    }        
}
