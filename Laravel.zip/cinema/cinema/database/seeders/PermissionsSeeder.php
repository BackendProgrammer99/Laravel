<?php


namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class PermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Reset cached roles and permissions
        // php artisan permission:cache-reset
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        Permission::create(['name' => 'customers.index']);
        Permission::create(['name' => 'customers.create']);
        Permission::create(['name' => 'customers.store']);
        Permission::create(['name' => 'customers.show']);
        Permission::create(['name' => 'customers.edit']);
        Permission::create(['name' => 'customers.update']);
        Permission::create(['name' => 'customers.destroy']);

        Permission::create(['name' => 'pricelists.index']);
        Permission::create(['name' => 'pricelists.create']);
        Permission::create(['name' => 'pricelists.store']);
        Permission::create(['name' => 'pricelists.show']);
        Permission::create(['name' => 'pricelists.edit']);
        Permission::create(['name' => 'pricelists.update']);
        Permission::create(['name' => 'pricelists.destroy']);

        Permission::create(['name' => 'services.index']);
        Permission::create(['name' => 'services.create']);
        Permission::create(['name' => 'services.store']);
        Permission::create(['name' => 'services.show']);
        Permission::create(['name' => 'services.edit']);
        Permission::create(['name' => 'services.update']);
        Permission::create(['name' => 'services.destroy']);

        Permission::create(['name' => 'reservations.index']);
        Permission::create(['name' => 'reservations.create']);
        Permission::create(['name' => 'reservations.store']);
        Permission::create(['name' => 'reservations.show']);
        Permission::create(['name' => 'reservations.edit']);
        Permission::create(['name' => 'reservations.update']);
        Permission::create(['name' => 'reservations.destroy']);

        Permission::create(['name' => 'users.index']);

        // ADMINSTRATOR SYSTEMU
        $userRole = Role::findByName(config('permission.roles.admin'));
        $userRole->givePermissionTo('services.index');
        $userRole->givePermissionTo('services.show');

        $userRole->givePermissionTo('reservations.index');
        $userRole->givePermissionTo('reservations.create');
        $userRole->givePermissionTo('reservations.store');
        $userRole->givePermissionTo('reservations.show');
        $userRole->givePermissionTo('reservations.edit');
        $userRole->givePermissionTo('reservations.update');
        $userRole->givePermissionTo('reservations.destroy');
        
        $userRole->givePermissionTo('pricelists.index');

        $userRole->givePermissionTo('customers.index');
        $userRole->givePermissionTo('customers.create');
        $userRole->givePermissionTo('customers.store');
        $userRole->givePermissionTo('customers.show');
        $userRole->givePermissionTo('customers.edit');
        $userRole->givePermissionTo('customers.update');
        
        $userRole->givePermissionTo('users.index');


        // Pracownik 
        $userRole = Role::findByName(config('permission.roles.worker'));
        $userRole->givePermissionTo('customers.index');
        $userRole->givePermissionTo('customers.create');
        $userRole->givePermissionTo('customers.store');
        $userRole->givePermissionTo('customers.show');
        $userRole->givePermissionTo('customers.edit');
        $userRole->givePermissionTo('customers.update');
        $userRole->givePermissionTo('customers.destroy');

        $userRole->givePermissionTo('pricelists.index');
        $userRole->givePermissionTo('pricelists.create');
        $userRole->givePermissionTo('pricelists.store');
        $userRole->givePermissionTo('pricelists.show');
        $userRole->givePermissionTo('pricelists.edit');
        $userRole->givePermissionTo('pricelists.update');
        $userRole->givePermissionTo('pricelists.destroy');


        $userRole->givePermissionTo('services.index');
        $userRole->givePermissionTo('services.create');
        $userRole->givePermissionTo('services.store');
        $userRole->givePermissionTo('services.show');
        $userRole->givePermissionTo('services.edit');
        $userRole->givePermissionTo('services.update');
        $userRole->givePermissionTo('services.destroy');

        $userRole->givePermissionTo('reservations.index');
        $userRole->givePermissionTo('reservations.create');
        $userRole->givePermissionTo('reservations.store');
        $userRole->givePermissionTo('reservations.show');
        $userRole->givePermissionTo('reservations.edit');
        $userRole->givePermissionTo('reservations.update');
        $userRole->givePermissionTo('reservations.destroy');

        $userRole->givePermissionTo('users.index');
        
        // USER SYSTEMU
        $userRole = Role::findByName(config('permission.roles.user'));
        $userRole->givePermissionTo('reservations.index');
        $userRole->givePermissionTo('reservations.create');
        $userRole->givePermissionTo('reservations.store');
        $userRole->givePermissionTo('reservations.show');
        $userRole->givePermissionTo('reservations.edit');
        $userRole->givePermissionTo('reservations.update');
        $userRole->givePermissionTo('services.index');
        $userRole->givePermissionTo('services.show');
        $userRole->givePermissionTo('pricelists.index');
        $userRole->givePermissionTo('pricelists.show');
    }
}

