<?php

namespace Database\Seeders;
use App\Models\Pricelist;
use Faker\Factory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PricelistsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    $faker = Factory::create("pl_PL");
    $rangeMax = 1000.0;
    for($i = 0; $i < 50; $i++) {
        DB::table('pricelists')->insert([
            // losowy wyraz
            'name' => $faker->word,
            'price'=> (rand() % $rangeMax)/100.0,
            'timenr'=> rand(1, 4),
            'unit'=> 'godzina',
            // losowa data w zadanym zakresie
            'created_at' => $faker->dateTimeBetween(
                 '-40 days',
                 '-20 days'
             ),
             'updated_at' => rand(0, 9) < 5
                ? null
                : $faker->dateTimeBetween(
                    '-15 days',
                    '-10 days'
              ),
              'deleted_at' => rand(0, 9) < 8
                 ? null
                 : $faker->dateTimeBetween(
                     '-5 days',
                     'now'
               )
        ]);
    }
    }        
}
