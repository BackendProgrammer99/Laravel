<?php
namespace Database\Seeders;
use Carbon\Carbon;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;


class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'Użytkownik',
            'email' => 'user@localhost',
            'position' => 'klient',
            'password' => bcrypt('Qazqaz12345!@')
        ]);
        $role = Role::findByName(config('permission.roles.user'));

        if(isset($role)) {
            $user->assignRole($role);
        }


        $user = User::create([
            'name' => 'Administrator',
            'email' => 'admin@localhost',
            'position' => 'admin',
            'password' => bcrypt('Qazqaz12345!@')
        ]);
        $role = Role::findByName(config('permission.roles.admin'));
        if(isset($role)) {
            $user->assignRole($role);
        }

        $user = User::create([
            'name' => 'Pracownik',
            'email' => 'worker@localhost',
            'position' => 'pracownik',
            'password' => bcrypt('Qazqaz12345!@')
        ]);
        $role = Role::findByName(config('permission.roles.worker'));
        if(isset($role)) {
            $user->assignRole($role);
        }        
    }

}
