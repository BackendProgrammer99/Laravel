<?php

namespace App\Http\Controllers;
use App\Http\Requests\Pricelists\PricelistRequest;
use Illuminate\Http\Request;
use App\Models\Pricelist;
class PricelistController extends Controller
{
    /**
     * Lista ...
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pricelists = Pricelist::withTrashed()->get();
        return view('pricelists.index', compact('pricelists'));
        
    }

   /**
     * Formularz dodawania ...
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pricelists.form');
    }

    /**
     * Dodanie ...
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PricelistRequest $request)
    {
        
        // stworzenie obiektu kategorii
        $pricelist = new Pricelist([
            'name' => $request->input('name'),
            'price' => $request->input('price'),
            'timenr' => $request->input('timenumber'),
            'unit' => $request->input('unit')
        ]);
        // zapisanie w bazie danych
        try {
            $pricelist->save();
            // przekierowanie na stronę z informacją o kategoriach
            return redirect()->route('pricelists.index')
                ->with('success', __('translation.pricelists.create.messages.success'));
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            // duplikacja klucza - jest to sprawdzane w regułach walidacji
            switch($e->getCode()){
                case '23000':
                    return redirect()->route('pricelists.index')
                        ->with('error', __('translation.pricelists.create.messages.duplicate_entry'));
                    break;
                default:
                    return redirect()->route('pricelists.index')
                        ->with('error', __('translation.pricelists.create.messages.error'));
            }
        }
    }
    

    /**
     * Wyświetlanie szczegółów wybranej ...
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $pricelist = Pricelist::findOrFail($id);
        return view('pricelists.show', compact('pricelist'));
    }

    /**
     * Formularz edycji ...
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pricelist = Pricelist::findOrFail($id);
        $edit = true;
        return view('pricelists.form', compact('pricelist', 'edit'));
   
    }

    /**
     * Aktualizacja ...
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PricelistRequest $request, $id)
    {
        try {
            // pobranie aktualnej kategorii z bazy
            $pricelist= Pricelist::findOrFail($id);
            // aktualizacja w bazie danych
            $pricelist->name = $request->input('name');
            $pricelist->price = $request->input('price');
            $pricelist->timenr = $request->input('timenumber');
            $pricelist->unit = $request->input('unit');
            $pricelist->save();
            // przekierowanie na stronę z informacją o kategoriach
            return redirect()->route('pricelists.index')
                ->with('success', __('translation.pricelists.edit.messages.success'));
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            // duplikacja klucza - jest to sprawdzane w regułach walidacji
            switch($e->getCode()){
                case '23000':
                    return redirect()->route('pricelists.index')
                        ->with('error', __('translation.pricelists.edit.messages.duplicate_entry'));
                    break;
                default:
                    return redirect()->route('pricelists.index')
                        ->with('error', __('translation.pricelists.edit.messages.error'));
            }
        }
    }
    

    /**
     * Usunięcie ...
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $pricelist = Pricelist::findOrFail($id);

        //usunięcie klienta
        $pricelist->delete();

        return redirect()->route('pricelists.index')
            ->with('success', __('translation.pricelists.destroy.messages.success'));
    }
}
