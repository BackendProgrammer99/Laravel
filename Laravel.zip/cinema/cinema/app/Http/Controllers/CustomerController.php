<?php

namespace App\Http\Controllers;
use App\Http\Requests\Customers\CustomerRequest;
use App\Models\Customer;
use Yajra\DataTables\Facades\DataTables;
class CustomerController extends Controller
class CustomerController extends Controller
{
    /**
     * Lista ...
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = Customer::withTrashed()->get();
        return view('customers.index', compact('customers'));
    }
     /**
     * Formularz dodawania ...
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('customers.form');
    }
    /**
     * Dodanie ...
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CustomerRequest $request)
    {
        
        // stworzenie obiektu kategorii
        $customer = new Customer([
            'name' => $request->input('name'),
            'street' => $request->input('street'),
            'homenumber' => $request->input('homenumber'),
            'postalcode' => $request->input('postalcode'),
            'locality' => $request->input('locality'),
            'phonenumberr' => $request->input('phonenumber')
        ]);
    }
    /**
     * Wyświetlanie szczegółów wybranej ...
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $customer = Customer::findOrFail($id);
        return view('customers.show', compact('customer'));
    }
    /**
     * Formularz edycji ...
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $customer = Customer::findOrFail($id);
        $edit = true;
        
        return view('customers.form', compact('customer', 'edit'));
   
    }

    /**
     * Aktualizacja ...
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CustomerRequest $request, $id)
    {
        try {
            // pobranie aktualnej kategorii z bazy
            $customer= Customer::findOrFail($id);
            // aktualizacja w bazie danych
            $customer->name = $request->input('name');
            $customer->street = $request->input('street');
            $customer->homenr = $request->input('homenumber');
            $customer->postalcode = $request->input('postalcode');
            $customer->locality = $request->input('locality');
            $customer->phonenr = $request->input('phonenumber');
            $customer->save();
            // przekierowanie na stronę z informacją o kategoriach
            return redirect()->route('customers.index')
                ->with('success', __('Zaktualizowano dane'));
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            // duplikacja klucza - jest to sprawdzane w regułach walidacji
            switch($e->getCode()){
                case '23000':
                    return redirect()->route('customers.index')
                        ->with('error', __('Dany klient już istnieje '));
                    break;
                default:
                    return redirect()->route('customers.index')
                        ->with('error', __('Błąd podczas aktualizacji dane usługi'));
            }
        }
    }
    /**
     * Usunięcie ...
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customer = Customer::findOrFail($id);

        //usunięcie klienta
        $customer->delete();

        return redirect()->route('customers.index')
            ->with('success', 'Usunięto klienta');
    }
    public function restore($id)
    {
        //odtworzenie usunięcia
        $customer = Customer::withTrashed()->findOrFail($id);

        // przywrócenie Klient
        $customer->restore();

        return redirect()->route('customer.index')
            ->with('success', 'Aktywowano klient');
    }
}
