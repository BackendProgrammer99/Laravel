<?php

namespace App\Http\Controllers;

use App\Http\Requests\Reservations\ReservationRequest;
use App\Models\Customer;
use App\Models\Service;
use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class ReservationController extends Controller
{
    /**
     * Lista produktów
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->hasRole('user'))
            $reservations = Reservation::where('customer_id',Auth::id())->with('service', 'customer')->get();
        else
            $reservations = Reservation::with('service', 'customer')->get();
        // zrenderowanie widoku
        return view('reservations.index', compact('reservations'));
    }

    /**
     * Formularz dodawania produktu
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $customers = Customer::all();
        $services = Service::all();
        return view('reservations.form',
            compact(
                'customers',
                'services'
            )
        );
    }

    /**
     * Dodawanie produktu
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ReservationRequest $request)
    {
        try {
            // zapisanie w bazie danych
            $reservation = new Reservation([
                'data' => $request->input('data'),
                'timefrom' => $request->input('timefrom'),
                'timeto' => $request->input('timeto'),
                'numberofpeople' => $request->input('numberofpeople'),
                'endprice' => $request->input('endprice'),
                'service_id' => $request->input('services_id'),
                'customer_id' => $request->input('customers_id'),
            ]);
            $reservation->save();
            // przekierowanie na stronę z informacją o produktach
            return redirect()->route('reservations.index')
                ->with('success', __('translation.reservations.create.messages.success'));
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            return redirect()->route('reservations.index')
                ->with('error', __('translation.prodcuts.create.messages.errors'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Formularz edycji produktu
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reservation = Reservation::findOrFail($id);
        $customers = Customer::all();
        $services = Service::all();
        $edit = true;
        return view('reservations.form',
            compact(
                'reservation',
                'customers',
                'services',
                'edit'
            )
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ReservationRequest $request, $id)
    {
        try {
            // pobranie aktualnego rekordu z bazy
            $reservation = Reservation::findOrFail($id);
            // aktualizacja w bazie danych
            $reservation->data = $request->input('data');
            $reservation->timefrom = $request->input('timefrom');
            $reservation->timeto = $request->input('timeto');
            $reservation->numberofpeople = $request->input('numberofpeople');
            $reservation->endprice = $request->input('endprice');
            $reservation->service_id = $request->input('services_id');
            $reservation->customer_id = $request->input('customers_id');
            $reservation->save();
            // przekierowanie na stronę z informacją o produktach
            return redirect()->route('reservations.index')
                ->with('success', __('translation.reservations.edit.messages.success'));
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            return redirect()->route('reservations.index')
                ->with('error', __('translation.reservations.edit.messages.error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $reservation = Reservation::findOrFail($id);
        $reservation->delete();
        return redirect()->route('reservations.index')
        ->with('success', __('Usunięto'));
    }
}
