<?php

namespace App\Http\Controllers;

use App\Models\Pricelist;
use App\Http\Requests\Services\StoreServiceRequest;
use App\Http\Requests\Services\UpdateServiceRequest;
use App\Models\Service;
use Illuminate\Http\Request;
class ServiceController extends Controller
{
    /**
     * Lista produktów
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // pobranie wszystkich produktów
        $services = Service::with('pricelist')->get();
        // zrenderowanie widoku
        return view('services.index', compact('services'));
    }

    /**
     * Formularz dodawania produktu
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pricelists = Pricelist::all();
        return view('services.form', compact('pricelists'));
    }

    /**
     * Dodawanie produktu
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreServiceRequest $request)
    {
        try {
            // zapisanie w bazie danych
            $service = new Service([
                'name' => $request->input('name'),
                'pricelist_id' => $request->input('pricelists_id')
            ]);
            $service->save();

            // przekierowanie na stronę z informacją o produktach
            return redirect()->route('services.index')
                ->with('success', 'Dodanio usługę');
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            return redirect()->route('services.index')
                ->with('error','Błąd podczas dodawania usługi');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Formularz edycji produktu
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $service = Service::findOrFail($id);
        $pricelists = Pricelist::all();
        $edit = true;
        return view('services.form',
            compact(
                'service',
                'pricelists',
                'edit'
            )
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateServiceRequest $request, $id)
    {
        try {
            // pobranie aktualnego rekordu z bazy
            $service = Service::findOrFail($id);
            // aktualizacja w bazie danych
            $service->name = $request->input('name');
            $service->pricelist_id = $request->input('pricelists_id');
            $service->save();
            // przekierowanie na stronę z informacją o produktach
            return redirect()->route('services.index')
                ->with('success', 'Zaktualizowano dane');
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            return redirect()->route('services.index')
                ->with('error', 'Błąd podczas aktualizacji dane usługi');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $service = Service::findOrFail($id);
        $service->delete();
        return redirect()->route('services.index')
        ->with('success', 'Usunięto');
    }
}
