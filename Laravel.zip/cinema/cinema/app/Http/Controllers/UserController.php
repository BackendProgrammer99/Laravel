<?php

namespace App\Http\Controllers;

use App\Http\Requests\Users\UserRequest;
use App\Models\User;
use Auth;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;

class UserController extends Controller
{
    /**
     * Widok wszystkich użytkowników
     * @param  App\DataTables\UsersDataTable $dataTable
     * @return
     */
    public function index(Request $request)
    {
        if( request()->ajax()) {
            $data = User::withTrashed();
            return Datatables::of($data)
                    ->editColumn('created_at', function ($user) {
                        return $user->created_at;
                    })
                    ->editColumn('updated_at', function ($user) {
                        return $user->updated_at;
                    })
                    ->editColumn('deleted_at', function ($user) {
                        return $user->deleted_at;
                    })
                    ->make(true);
        }
        return  view('users.index');
    }

    /**
     * Edycja profilu użytkownika
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editProfile()
    {
        $user = User::findOrFail(Auth::id());
        return view('users.edit-profile',
            compact(
                'user'
            )
        );
    }

    /**
     * Aktualizacja profilu użytkownika
     * @param  UserRequest $request
     * @return
     */
    public function updateProfile(UserRequest $request)
    {
        try {
            // pobranie aktualnego rekordu z bazy
            $user = User::findOrFail(Auth::id());
            // aktualizacja w bazie danych
            $user->name = $request->input('name');
            $user->save();
            // przekierowanie na stronę z informacją o kategoriach
            return back()->with('success', 'Zakutalizowano dane użytkownika');
        } catch(\Illuminate\Database\QueryException $e) {
            \Log::error($e);
            return redirect()->route('users.edit_profile')
                ->with('error','Błąd podczas aktualizacji danych użytkownika');
        }
    }
   
}
