<?php

namespace App\Http\Requests\Services;

use App\Models\Service;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreServiceRequest extends FormRequest
{
    /**
     * Reguły walidacji
     *
     * @return array
     */
    public function rules()
    {
       
        return [
            'name'=> [
                'required',
                'max:50',
            ],
            'pricelist_id' => [
                'integer'
            ]
        ];
    }
}