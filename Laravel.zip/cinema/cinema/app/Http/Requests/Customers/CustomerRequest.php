<?php

namespace App\Http\Requests\Customers;

use App\Models\Customer;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CustomerRequest extends FormRequest
{
    /**
     * Reguły walidacji
     *
     * @return array
     */
    public function rules()
    {

        return [
            'name'=> [
                'required',
                'max:60'
            ],
            'street'=> [
                'required',
                'max:50',
            ],
            'homenumber'=> [
                'required',
                'max:50'
            ],
            'postalcode'=> [
                'required',
                'max:6',
                'size:6'
            ],
            'locality'=> [
                'required',
                'max:50',
                'string'
            ],
            'phonenumber'=> [
                'required',
            ]
        ];
    }
}
