<?php

namespace App\Http\Requests\Reservations;

use App\Models\Reservation;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ReservationRequest extends FormRequest
{
    /**
     * Reguły walidacji
     *
     * @return array
     */
    public function rules()
    {
        return [
            'data'=> [
                'required'
            ],
            'timefrom'=> [
                'required'
            ],
            'timeto'=> [
                'required',
                'after:timefrom'
            ],
            'numberofpeople'=> [
                'required',
                'numeric'
            ],
            'endprice'=> [
                'required',
                'regex:/^\d+(\.\d{1,2})?$/'
            ],
            'service_id' => [
                'integer'
            ],
            'customer_id' => [
                'integer'
            ]
        ];
    }
}