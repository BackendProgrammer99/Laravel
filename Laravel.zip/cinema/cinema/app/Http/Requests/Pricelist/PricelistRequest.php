<?php

namespace App\Http\Requests\Pricelists;

use App\Models\Pricelist;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PricelistRequest extends FormRequest
{
    /**
     * Reguły walidacji
     *
     * @return array
     */
    public function rules()
    {
        
        return [
            'name'=> [
                'required',
                'max:50'
            ],
            'price'=> [
                'required',
                'regex:/^\d+(\.\d{1,2})?$/'
            ],
            'timenumber'=> [
                'required',
                'numeric'
            ],
            'unit'=> [
                'required'
            ]
        ];
    }
}
