<?php

namespace App\Http\Requests\Users;

use Illuminate\Foundation\Http\FormRequest;

/**
 * Class UpdateUserRequest.
 */
class UserRequest extends FormRequest
{
    /**
     * Reguły walidacji dla UpdateUserRequest
     *
     * @return array
     */
    public function rules()
    {

        return [
            'name'=> [
                'required',
                'max:50'
            ]
        ];
    }
}
