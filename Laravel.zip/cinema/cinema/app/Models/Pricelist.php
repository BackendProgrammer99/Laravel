<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Pricelist extends Model
{
    use SoftDeletes;
    use HasFactory;
    //pola wypełniane
    //protected $table = 'pricelists';
    protected $fillable = [
        'name' ,
        'price',
        'timenumber',
        'unit'
    ];
    public function service()
    {
        return $this->hasMany('App\Models\Service');
    }
}
