<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $fillable = [
        'data',
        'timefrom',
        'timeto',
        'numberofpeople',
        'endprice',
        'service_id',
        'customer_id',
    ];
    /**
     * Produkt należy do kategorii: relacja many-to-one
     */
    public function service()
    {
        return $this->belongsTo(Service::class)->withTrashed();
    }
    public function customer()
    {
        return $this->belongsTo(Customer::class)->withTrashed();
    }
}