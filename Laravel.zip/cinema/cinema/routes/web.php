<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\PricelistController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::middleware('auth')->group(function () {
    Route::group(['prefix' => 'customers'],function(){
        Route::get('/', [CustomerController::class, 'index'])->name('customers.index')->middleware(['permission:customers.index']);
        Route::get('create', [CustomerController::class, 'create'])->name('customers.create')->middleware(['permission:customers.create']);
        Route::post('store', [CustomerController::class, 'store'])->name('customers.store')->middleware(['permission:customers.store']);
        Route::get('{id}', [CustomerController::class, 'show'])->name('customers.show')->middleware(['permission:customers.show']);
        Route::get('{id}/edit', [CustomerController::class, 'edit'])->name('customers.edit')->middleware(['permission:customers.edit']);
        Route::put('{id}', [CustomerController::class, 'update'])->name('customers.update')->middleware(['permission:customers.update']);
        Route::delete('{id}', [CustomerController::class, 'destroy'])->name('customers.destroy')->middleware(['permission:customers.destroy']);
    });
    
    Route::group(['prefix' => 'pricelists'],function(){
        Route::get('/', [PricelistController::class, 'index'])->name('pricelists.index')->middleware(['permission:pricelists.index']);
        Route::get('create', [PricelistController::class, 'create'])->name('pricelists.create')->middleware(['permission:pricelists.create']);
        Route::post('store', [PricelistController::class, 'store'])->name('pricelists.store')->middleware(['permission:pricelists.store']);
        Route::get('{id}', [PricelistController::class, 'show'])->name('pricelists.show')->middleware(['permission:pricelists.show']);
        Route::get('{id}/edit', [PricelistController::class, 'edit'])->name('pricelists.edit')->middleware(['permission:pricelists.edit']);
        Route::put('{id}', [PricelistController::class, 'update'])->name('pricelists.update')->middleware(['permission:pricelists.update']);
        Route::delete('{id}', [PricelistController::class, 'destroy'])->name('pricelists.destroy')->middleware(['permission:pricelists.destroy']);
    });
    Route::group(['prefix' => 'services'],function(){
        Route::get('/', [ServiceController::class, 'index'])->name('services.index')->middleware(['permission:services.index']);
        Route::get('create', [ServiceController::class, 'create'])->name('services.create')->middleware(['permission:services.create']);
        Route::post('store', [ServiceController::class, 'store'])->name('services.store')->middleware(['permission:services.store']);
        Route::get('{id}', [ServiceController::class, 'show'])->name('services.show')->middleware(['permission:services.show']);
        Route::get('{id}/edit', [ServiceController::class, 'edit'])->name('services.edit')->middleware(['permission:services.edit']);
        Route::put('{id}', [ServiceController::class, 'update'])->name('services.update')->middleware(['permission:services.update']);
        Route::delete('{id}', [ServiceController::class, 'destroy'])->name('services.destroy')->middleware(['permission:services.destroy']);
    });
    Route::group(['prefix' => 'reservations'],function(){
        Route::get('/', [ReservationController::class, 'index'])->name('reservations.index')->middleware(['permission:reservations.index']);
        Route::get('create', [ReservationController::class, 'create'])->name('reservations.create')->middleware(['permission:reservations.create']);
        Route::post('store', [ReservationController::class, 'store'])->name('reservations.store')->middleware(['permission:reservations.store']);
        Route::get('{id}', [ReservationController::class, 'show'])->name('reservations.show')->middleware(['permission:reservations.show']);
        Route::get('{id}/edit', [ReservationController::class, 'edit'])->name('reservations.edit')->middleware(['permission:reservations.edit']);
        Route::put('{id}', [ReservationController::class, 'update'])->name('reservations.update')->middleware(['permission:reservations.update']);
        Route::delete('{id}', [ReservationController::class, 'destroy'])->name('reservations.destroy')->middleware(['permission:reservations.destroy']);
    });
    Route::group(['prefix' => 'users'],function(){
        Route::get('', [UserController::class, 'index'])->name('users.index')->middleware(['permission:users.index']);
        Route::get('edit-profile', [UserController::class, 'editProfile'])->name('users.edit-profile');
        Route::put('edit-profile',  [UserController::class, 'updateProfile'])->name('users.update-profile');
    });
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


