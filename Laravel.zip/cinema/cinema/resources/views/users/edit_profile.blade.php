@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-8 offset-sm-2 mt-3">
            <div class="card">
                <div class="card-body">
                    <h1 class="card-title mt-5">EDYTUJ PROFIL</h1>

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form id="users-form" method="post" action="{{ route('users.edit-profile') }}">
                        @method('PUT')
                        @csrf
                        <div class="form-group">
                            <label for="name">Imie i Nazwisko</label>
                            <input type="text" class="form-control" name="name" @if (isset($user->name))
                            value="{{ $user->name }}"
                        @else
                            value="{{ old('name') }}"
                            @endif
                            required
                            />
                        </div>
                        <div class="float-right">
                            <a href="{{ url()->previous() }}" type="button" class="btn btn-secondary">ANULUJ</a>
                            <button type="submit" class="btn btn-primary">
                                ZAPISZ
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <div>

            </div>
        </div>
    </div>
@endsection
{{-- Dodanie do szablonu lokalnych skryptów JS --}}
@section('js-scripts')
    {{-- Laravel Javascript Validation --}}
    <script type="text/javascript" src="{{ url('vendor/jsvalidation/js/jsvalidation.js') }}"></script>

    {{-- Walidacja po stronie klienta z użyciem reguł walidacji po stronie serwera --}}
    {!! JsValidator::formRequest('App\Http\Requests\Users\UserRequest', '#users-form') !!}
@endsection
