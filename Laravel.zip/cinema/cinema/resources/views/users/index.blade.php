@extends('layouts.app')
@section('css-styles')
    <link href="{{ url('css/external/datatables.min.css') }}" rel="stylesheet">
@endsection

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <h1 style="margin: 19px;" class="display-2 mt-5">UŻYTKOWNICY</h1>
            <div style="margin-bottom: 50px">
                <div class="btn-group float-right">
                    @can('users.create')
                        {{-- <a href="{{ route('users.create')}}"
                    class="btn btn-primary">{{ __('Dodaj użytkownika', ['model' => 'users']) }}</a> --}}
                    @endcan
                </div>
            </div>
            <table id="users-table" class="table table-striped display" style="width:100%">
                <thead>
                    <tr>
                        <td>Numer</td>
                        <th>Imie i nazwisko</th>
                        <th>Email</th>
                        <th>Stanowisko</th>
                        <td>Data utworzenia</td>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection
@section('js-scripts')
    <script type="text/javascript" src="{{ url('js/external/datatables.min.js') }}"></script>
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script>
        $(document).ready(function() {
            $.noConflict();
            $('#users-table').DataTable({
                processing: true, // wyświetlanie komunikatu o przetwarzaniu
                serverSide: true, // przetwarzanie po stronie serwera
                ajax: {
                    url: '{!! route('users.index') !!}',
                    type: 'GET',
                    // podczas wysyłania metodą POST koniecznie jest dodanie tokena
                    // zabezpieczającego przed atakami CSRF
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                },
                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'email',
                        name: 'email'
                    },
                    {
                        data: 'position',
                        name: 'position'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },

                ],
            });
        });
    </script>
@endsection
