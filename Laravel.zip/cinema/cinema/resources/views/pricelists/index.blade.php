@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <h1 style="margin: 19px;" class="display-2 mt-5">CENNIK</h1>
            @if (Auth::check() && Auth::user()->hasRole('admin'))
                <div class="text-right">
                    <a style="margin: 19px;" href="{{ route('pricelists.create') }}" class="btn btn-primary">
                        {{ __('DODAJ DO CENNIKA') }}
                    </a>
                </div>
            @endif

            <table class="table table-striped">
                <thead>
                    <tr>
                        <td>Numer</td>
                        <td>Rodzaj usługi</td>
                        <td>Cena</td>
                        <td>Za ile czasu</td>
                        <td>Jednostka miary</td>
                        <td>Data utworzenia</td>
                        <td>Data aktualizacji</td>
                        <td>Data usunięcia</td>
                        @if (Auth::check() && Auth::user()->hasRole('admin'))
                            <td>Edytuj</td>
                            <td>Usuń</td>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @foreach ($pricelists as $pricelist)
                        <tr>
                            <td>{{ $pricelist->id }}</td>
                            <td>
                                @if (!isset($pricelist->deleted_at))
                                    <a href="{{ route('pricelists.show', $pricelist->id) }}" class="btn btn-primaty">
                                        {{ $pricelist->name }}
                            <td>{{ $pricelist->price }}</td>
                            <td>{{ $pricelist->timenr }}</td>
                            <td>{{ $pricelist->unit }}</td>
                        @else
                            {{ $pricelist->name }}
                            <td>{{ $pricelist->price }}</td>
                            <td>{{ $pricelist->timenr }}</td>
                            <td>{{ $pricelist->unit }}</td>
                    @endif
                    </td>
                    <td>{{ $pricelist->created_at }}</td>
                    <td>{{ $pricelist->updated_at }}</td>
                    <td>{{ $pricelist->deleted_at }}</td>

                    @if (Auth::check() && Auth::user()->hasRole('admin'))
                        <td>
                            @if (!isset($pricelist->deleted_at))
                                <a href="{{ route('pricelists.edit', $pricelist->id) }}" class="btn btn-primary">
                                    {{ __('EDYTUJ') }}
                                </a>
                            @endif
                        </td>
                        <td>
                            @if (!isset($pricelist->deleted_at))
                                <form action="{{ route('pricelists.destroy', $pricelist->id) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger" type="submit">
                                        {{ __('USUŃ') }}
                                    </button>
                                </form>
                            @endif
                        </td>
                    @endif

                    </tr>
                    @endforeach
                </tbody>
            </table>
            <div>
            </div>
        @endsection

        @section('js-scripts')
            <script type="text/javascript" src="{{ url('js/plugins/confirm_destroy.min.js') }}"></script>
            <script type="text/javascript" src="{{ url('js/external/datatables.min.js') }}"></script>

            <script src="{{ asset('js/app.js') }}" defer></script>

        @endsection
