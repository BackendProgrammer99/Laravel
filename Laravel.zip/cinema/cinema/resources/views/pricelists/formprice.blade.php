@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-8 offset-sm-2">
            <h1 class="display-3 mt-5">
                @if (isset($edit) && $edit === true)
                    {{ __('EDYTUJ CENNIK') }}
                @else
                    {{ __('DODAJ DO CENNIKA') }}
                @endif
            </h1>
            <div>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <form id="pricelist-form" method="post" @if (isset($edit) && $edit === true)
                    action="{{ route('pricelists.update', $pricelist->id) }}"
                @else
                    action="{{ route('pricelists.store') }}"
                    @endif

                    >
                    @if (isset($edit) && $edit === true)
                        @method('PUT')
                    @endif
                    @csrf
                    <div class="form-group">
                        <label for="name">Dni tygodnia</label>
                        <input type="text" class="form-control" name="name" @if (isset($pricelist->name))
                        value="{{ $pricelist->name }}"
                    @else
                        value="{{ old('name') }}"
                        @endif
                        />
                        <div class="form-group">
                            <label for="price">Cena</label>
                            <input type="number" step="0.01" min="10.0" class="form-control" name="price" @if (isset($pricelist->price))
                            value="{{ $pricelist->price }}"
                        @else
                            value="{{ old('price') }}"
                            @endif
                            />
                            <div class="form-group">
                                <label for="timenr">Czas</label>
                                <input type="number" class="form-control" name="timenr" @if (isset($pricelist->timenr))
                                value="{{ $pricelist->timenr }}"
                            @else
                                value="{{ old('timenumber') }}"
                                @endif
                                />
                                <div class="form-group">
                                    <label for="unit">Jednostka czasu</label>
                                    <input type="text" class="form-control" name="unit" @if (isset($pricelist->unit))
                                    value="{{ $pricelist->unit }}"
                                @else
                                    value="{{ old('unit') }}"
                                    @endif
                                    />
                                </div>
                                <a href="{{ route('pricelists.index') }}" type="button" class="btn btn-secondary">
                                    {{ __('ANULUJ') }}
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    @if (isset($edit) && $edit === true)
                                        {{ __('AKTUALIZUJ') }}
                                    @else
                                        {{ __('DODAJ') }}
                                    @endif
                                </button>
                </form>
            </div>
        </div>
    @endsection
    {{-- Dodanie do szablonu lokalnych skryptów JS --}}
    @section('js-scripts')
        {{-- Laravel Javascript Validation --}}
        <script type="text/javascript" src="{{ url('vendor/jsvalidation/js/jsvalidation.js') }}"></script>

        {{-- Walidacja po stronie klienta z użyciem reguł walidacji po stronie serwera --}}
        @if (isset($edit) && $edit === true)
            {!! JsValidator::formRequest('App\Http\Requests\Pricelists\PricelistRequest', '#pricelist-form') !!}
        @else
            {!! JsValidator::formRequest('App\Http\Requests\Pricelists\PricelistRequest', '#pricelist-form') !!}
        @endif
    @endsection
