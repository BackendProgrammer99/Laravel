@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-8 offset-sm-2">
            <h1 class="display-3 mt-5">
                {{ __('CENNIK') }}
            </h1>
            <div>
                {{ __('Id') }}: {{ $pricelist->id }}<br />
                {{ __('name') }}: {{ $pricelist->name }}<br />
                {{ __('price') }}: {{ $pricelist->price }}<br />
                {{ __('timenr') }}: {{ $pricelist->timenr }}<br />
                {{ __('unit') }}: {{ $pricelist->unit }}<br />
                {{ __('created_at') }}: {{ $pricelist->created_at }}<br />
                {{ __('updated_at') }}: {{ $pricelist->updated_at }}<br />
            </div>
            <div>
                <br />
                <a href="{{ route('pricelists.index') }}" type="button" class="btn btn-secondary">
                    << {{ __('CENNIK') }} </a>
            </div>
        </div>
    </div>
@endsection
