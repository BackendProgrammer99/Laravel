@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-8 offset-sm-2">
            <h1 class="display-3 mt-5">
                @if (isset($edit) && $edit === true)
                    {{ __('EDYTUJ KLIENTÓW') }}
                @else
                    {{ __('DODAJ KLIENTA') }}
                @endif
            </h1>
            <div class="col-sm-8 offset-sm-2">
                <div>
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form id="customer-form" method="post" @if (isset($edit) && $edit === true)
                        action="{{ route('customers.update', $customer->id) }}"
                    @else
                        action="{{ route('customers.store') }}"
                        @endif

                        >
                        @if (isset($edit) && $edit === true)
                            @method('PUT')
                        @endif
                        @csrf
                        <div class="form-group">
                            <label for="name">Imie i Nazwisko</label>
                            <input type="text" class="form-control" name="name" @if (isset($customer->name))
                            value="{{ $customer->name }}"
                        @else
                            value="{{ old('name') }}"
                            @endif
                            />
                            <div class="form-group">
                                <label for="phonenr">Numer telefonu</label>
                                <input type="numer" class="form-control" name="phonenr" @if (isset($customer->phonenr))
                                value="{{ $customer->phonenumber }}"
                            @else
                                value="{{ old('phonenumber') }}"
                                @endif
                                />
                                <div class="form-group">
                                    <label for="street">Ulica</label>
                                    <input type="text" class="form-control" name="street" @if (isset($customer->street))
                                    value="{{ $customer->street }}"
                                @else
                                    value="{{ old('street') }}"
                                    @endif
                                    />
                                    <div class="form-group">
                                        <label for="homenr">Numer domu</label>
                                        <input type="text" class="form-control" name="homenr" @if (isset($customer->homenr))
                                        value="{{ $customer->homenumber }}"
                                    @else
                                        value="{{ old('homenumber') }}"
                                        @endif
                                        />
                                        <div class="form-group">
                                            <label for="locality">Miejscowość</label>
                                            <input type="text" class="form-control" name="locality" @if (isset($customer->locality))
                                            value="{{ $customer->locality }}"
                                        @else
                                            value="{{ old('locality') }}"
                                            @endif
                                            />
                                            <div class="form-group">
                                                <label for="postalcode">Kod pocztowy</label>
                                                <input type="numer" class="form-control" name="postalcode" @if (isset($customer->postalcode))
                                                value="{{ $customer->postalcode }}"
                                            @else
                                                value="{{ old('postalcode') }}"
                                                @endif
                                                />
                                            </div>
                                        </div>
                                        <a href="{{ route('customers.index') }}" type="button" class="btn btn-secondary">
                                            {{ __('Anuluj') }}
                                        </a>
                                        <button type="submit" class="btn btn-primary">
                                            @if (isset($edit) && $edit === true)
                                                {{ __('Aktualizuj') }}
                                            @else
                                                {{ __('Dodaj') }}
                                            @endif
                                        </button>
                    </form>
                </div>
            </div>
        @endsection
        {{-- Dodanie do szablonu lokalnych skryptów JS --}}
        @section('js-scripts')
            {{-- Laravel Javascript Validation --}}
            <script type="text/javascript" src="{{ url('vendor/jsvalidation/js/jsvalidation.js') }}"></script>

            {{-- Walidacja po stronie klienta z użyciem reguł walidacji po stronie serwera --}}
            @if (isset($edit) && $edit === true)
                {!! JsValidator::formRequest('App\Http\Requests\Customers\CustomerRequest', '#customer-form') !!}
            @else
                {!! JsValidator::formRequest('App\Http\Requests\Customers\CustomerRequest', '#customer-form') !!}
            @endif
        @endsection
