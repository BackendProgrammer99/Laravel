@extends('layouts.app')

@section('css-styles')
    <link href="{{ url('css/external/datatables.min.css') }}" rel="stylesheet">
@endsection

@section('content')
    <div class="row">
        <div class="col-sm-13">
            {{-- @include('layouts.alert') --}}
            <h1 style="margin: 19px;" class="display-2 mt-5">{{ 'INFORMACJE O KLIENTACH' }}</h1>

            <div class="text-right">
                @can('customers.store')

                    <a style="margin: 19px;" href="{{ route('customers.create') }}" class="btn btn-primary">
                        {{ __('DODAJ KLIENTA', ['model' => 'customers']) }}
                    </a>
                @endcan

            </div>
            <table id="customers-table" class="table table-striped small" style="width:100%">
                <thead>
                    <tr>
                        <td>ID Klienta</td>
                        <td>Imie Nazwisko</td>
                        <td>Ulica</td>
                        <td>Numer domu</td>
                        <td>Kod pocztowy</td>
                        <td>Miejscowość</td>
                        <td>Numer telefonu</td>
                        <td>Utworzono</td>
                        <td>Zaktualizowano</td>
                        <td>Usunięto</td>
                        @if (Auth::check() && Auth::user()->hasRole('admin'))
                            <td>Edytuj</td>
                            <td>Usuń</td>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @foreach ($customers as $customer)
                        <tr>
                            <td>{{ $customer->id }}</td>
                            <td>
                                @if (!isset($customer->deleted_at))
                                    <a href="{{ route('customers.show', $customer->id) }}" class="btn btn-primaty">
                                        {{ $customer->name }}
                            <td>{{ $customer->street }}</td>
                            <td>{{ $customer->homenumber }}</td>
                            <td>{{ $customer->postalcode }}</td>
                            <td>{{ $customer->locality }}</td>
                            <td>{{ $customer->phonenumber }}</td>
                        @else
                            {{ $customer->name }}
                            <td>{{ $customer->street }}</td>
                            <td>{{ $customer->homenumber }}</td>
                            <td>{{ $customer->postalcode }}</td>
                            <td>{{ $customer->locality }}</td>
                            <td>{{ $customer->phonenumber }}</td>
                    @endif
                    </td>
                    <td>{{ $customer->created_at }}</td>
                    <td>{{ $customer->updated_at }}</td>
                    <td>{{ $customer->deleted_at }}</td>

                    @if (Auth::check() && Auth::user()->hasRole('admin'))
                        <td>
                            @if (!isset($customer->deleted_at))
                                <a href="{{ route('customers.edit', $customer->id) }}" class="btn btn-primary">
                                    {{ __('EDYTUJ') }}
                                </a>
                            @endif
                        </td>
                        <td>
                            @if (!isset($customer->deleted_at))
                                <form action="{{ route('customers.destroy', $customer->id) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger" type="submit">
                                        {{ __('USUŃ') }}
                                    </button>
                                </form>
                            @endif
                        </td>
                    @endif

                    </tr>
                    @endforeach
                </tbody>
            </table>
            <div>
            </div>
        @endsection

        @section('js-scripts')
            <script type="text/javascript" src="{{ url('js/plugins/confirm_destroy.min.js') }}"></script>
            <script type="text/javascript" src="{{ url('js/external/datatables.min.js') }}"></script>
            <script src="{{ asset('js/app.js') }}" defer></script>

        @endsection
