@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-8 offset-sm-2">
            <h1 class="display-3 mt-5">
                {{ __('KLIENCI') }}
            </h1>
            <div>
                {{ __('Id') }}: {{ $customer->id }}<br />
                {{ __('name') }}: {{ $customer->name }}<br />
                {{ __('street') }}: {{ $customer->street }}<br />
                {{ __('homenr') }}: {{ $customer->homenumber }}<br />
                {{ __('postalcode') }}: {{ $customer->postalcode }}<br />
                {{ __('locality') }}: {{ $customer->locality }}<br />
                {{ __('phonenr') }}: {{ $customer->phonenumber }}<br />
                {{ __('created_at') }}: {{ $customer->created_at }}<br />
                {{ __('updated_at') }}: {{ $customer->updated_at }}<br />
            </div>
            <div>
                <br />
                <a href="{{ route('customers.index') }}" type="button" class="btn btn-secondary">
                    << {{ __('LISTA KLIENTÓW') }} </a>
            </div>
        </div>
    </div>
@endsection
