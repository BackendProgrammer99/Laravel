@extends('layouts.app')

@section('content')
    <div class="row mt-5">
        <div class="col-sm-12">
            <h1 class="display-3 mt-5">
                @if (isset($edit) && $edit === true)
                    {{ __('EDYTUJ DANE USŁUGI') }}
                @else
                    {{ __('DODAJ USŁUGĘ') }}
                @endif

            </h1>
        </div>
        <div class="col-sm-8 offset-sm-2">
            <div>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <form id="service-form" method="post" @if (isset($edit) && $edit === true)
                    action="{{ route('services.update', $service->id) }}"
                @else
                    action="{{ route('services.store') }}"
                    @endif
                    >
                    @if (isset($edit) && $edit === true)
                        @method('PUT')
                    @endif
                    @csrf
                    <div class="form-group">
                        <label for="name">Nazwa usługi</label>
                        <input type="text" class="form-control" name="name" @if (isset($service->name))
                        value="{{ $service->name }}"
                    @else
                        value="{{ old('name') }}"
                        @endif
                        required
                        />
                    </div>
                    <div class="form-group">
                        <label for="pricelist">Cennik</label>
                        <select class="form-control custom-select" name="pricelists_id">
                            <option></option>
                            @foreach ($pricelists as $pricelist)
                                <option value="{{ $pricelist->id }}" @if (isset($service->pricelist_id) && $service->pricelist_id === $pricelist->id)
                                    selected
                                @elseif (old('pricelists_id') && old('pricelists_id') === $pricelist->id)
                                    selected
                            @endif
                            >{{ $pricelist->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <a href="{{ route('services.index') }}" type="button" class="btn btn-secondary">
                        {{ __('ANULUJ') }}
                    </a>
                    <button type="submit" class="btn btn-primary">
                        @if (isset($edit) && $edit === true)
                            {{ __('AKTUALIZUJ') }}
                        @else
                            {{ __('DODAJ') }}
                        @endif
                    </button>
                </form>
            </div>
        </div>
    </div>

@endsection
{{-- Dodanie do szablonu lokalnych skryptów JS --}}
@section('js-scripts')
    {{-- Laravel Javascript Validation --}}
    <script type="text/javascript" src="{{ url('vendor/jsvalidation/js/jsvalidation.js') }}"></script>

    {{-- Walidacja po stronie klienta z użyciem reguł walidacji po stronie serwera --}}
    @if (isset($edit) && $edit === true)
        {!! JsValidator::formRequest('App\Http\Requests\Services\UpdateServiceRequest', '#service-form') !!}
    @else
        {!! JsValidator::formRequest('App\Http\Requests\Services\StoreServiceRequest', '#service-form') !!}
    @endif
@endsection
