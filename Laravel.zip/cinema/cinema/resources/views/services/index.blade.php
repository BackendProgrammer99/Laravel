@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <h1 style="margin: 19px;" class="display-2 mt-5">Usługi</h1>
            @if (Auth::check() && Auth::user()->hasRole('admin'))
                <div class="text-right">
                    <a style="margin: 19px;" href="{{ route('services.create') }}" class="btn btn-primary">
                        {{ __('DODAJ USŁUGĘ') }}
                    </a>
                </div>
            @endif
            <table class="table table-striped text-center">
                <thead>
                    <tr>
                        <td>Nr</td>
                        <td>Usługa</td>
                        <td>Cena</td>
                        <td>Data utworzenia</td>
                        <td>Data aktualizacji</td>
                        <td>Data usunięcia</td>
                        @if (Auth::check() && Auth::user()->hasRole('admin'))
                            <td colspan="2">{{ __('Akcje') }}</td>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @foreach ($services as $service)
                        <tr>
                            <td>{{ $service->id }}</td>
                            <td>{{ $service->name }}</td>
                            <td>
                                @if (isset($service->pricelist))
                                    {{ $service->pricelist->name }}
                                @endif
                            </td>
                            <td>{{ $service->created_at }}</td>
                            <td>{{ $service->updated_at }}</td>
                            <td>{{ $service->deleted_at }}</td>
                            @if (Auth::check() && Auth::user()->hasRole('admin'))
                                <td>
                                    @if (!isset($service->deleted_at))
                                        <a href="{{ route('services.edit', $service->id) }}" class="btn btn-primary">
                                            {{ __('EDYTUJ') }}
                                        </a>
                                    @endif
                                </td>
                                <td>
                                    @if (!isset($service->deleted_at))
                                        <form action="{{ route('services.destroy', $service->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-danger" type="submit">
                                                {{ __('USUŃ') }}
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            @endif
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
@section('js-scripts')
    <script type="text/javascript" src="{{ url('js/plugins/confirm_destroy.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/external/datatables.min.js') }}"></script>

    <script src="{{ asset('js/app.js') }}" defer></script>

@endsection
