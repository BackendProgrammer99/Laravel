@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <h1 class="display-3 mt-5">
                @if (isset($edit) && $edit === true)
                    {{ __('EDYTUJ REZERWACJE') }}
                @else
                    {{ __('DODAJ REZERWACJE') }}
                @endif

            </h1>
        </div>
        <div class="col-sm-8 offset-sm-2">
            <div>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                <form id="reservation-form" method="post" @if (isset($edit) && $edit === true)
                    action="{{ route('reservations.update', $reservation->id) }}"
                @else
                    action="{{ route('reservations.store') }}"
                    @endif
                    >
                    @if (isset($edit) && $edit === true)
                        @method('PUT')
                    @endif
                    @csrf
                    <div class="form-group">
                        <label for="data">Dzień</label>
                        <input type="date" class="form-control" name="data" @if (isset($reservation->data))
                        value="{{ $reservation->data }}"
                    @else
                        value="{{ old('data') }}"
                        @endif
                        required
                        />
                    </div>
                    <div class="form-group">
                        <label for="timefrom">Godzina od</label>
                        <input type="time" class="form-control" name="timefrom" @if (isset($reservation->timefrom))
                        value="{{ $reservation->timefrom }}"
                    @else
                        value="{{ old('timefrom') }}"
                        @endif
                        required
                        />
                    </div>
                    <div class="form-group">
                        <label for="timeto">Godzina do</label>
                        <input type="time" class="form-control" name="timeto" @if (isset($reservation->timeto))
                        value="{{ $reservation->timeto }}"
                    @else
                        value="{{ old('timeto') }}"
                        @endif
                        required
                        />
                    </div>
                    <div class="form-group">
                        <label for="numberofpeople">Liczba odwiedzających</label>
                        <input type="text" class="form-control" name="numberofpeople" @if (isset($reservation->numberofpeople))
                        value="{{ $reservation->numberofpeople }}"
                    @else
                        value="{{ old('numberofpeople') }}"
                        @endif
                        required
                        />
                    </div>
                    <div class="form-group">
                        <label for="endprice">Cena końcowa</label>
                        <input type="text" step="0.01" min="0.0" class="form-control" name="endprice" @if (isset($reservation->endprice))
                        value="{{ $reservation->endprice }}"
                    @else
                        value="{{ old('endprice') }}"
                        @endif
                        required
                        />
                    </div>
                    <div class="form-group">
                        <label for="service">Rodzaj usługi</label>
                        <select class="form-control custom-select" name="services_id">
                            <option></option>
                            @foreach ($services as $service)
                                <option value="{{ $service->id }}" @if (isset($reservation->service_id) && $reservation->service_id === $service->id)
                                    selected
                                @elseif (old('services_id') && old('services_id') === $service->id)
                                    selected
                            @endif
                            >{{ $service->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="customer">Klient</label>
                        <select class="form-control custom-select" name="customers_id">
                            <option></option>
                            @foreach ($customers as $customer)
                                <option value="{{ $customer->id }}" @if (isset($reservation->customer_id) && $reservation->customer_id === $customer->id)
                                    selected
                                @elseif (old('customers_id') && old('customers_id') === $customer->id)
                                    selected
                            @endif
                            >{{ $customer->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <a href="{{ route('reservations.index') }}" type="button" class="btn btn-secondary">
                        {{ __('Anuluj') }}
                    </a>
                    <button type="submit" class="btn btn-primary">
                        @if (isset($edit) && $edit === true)
                            {{ __('AKTUALIZUJ') }}
                        @else
                            {{ __('DODAJ') }}
                        @endif
                    </button>
                </form>
            </div>
        </div>
    </div>

@endsection
{{-- Dodanie do szablonu lokalnych skryptów JS --}}
@section('js-scripts')
    {{-- Laravel Javascript Validation --}}
    <script type="text/javascript" src="{{ url('vendor/jsvalidation/js/jsvalidation.js') }}"></script>

    {{-- Walidacja po stronie klienta z użyciem reguł walidacji po stronie serwera --}}
    @if (isset($edit) && $edit === true)
        {!! JsValidator::formRequest('App\Http\Requests\Reservations\ReservationRequest', '#reservation-form') !!}
    @else
        {!! JsValidator::formRequest('App\Http\Requests\Reservations\ReservationRequest', '#reservation-form') !!}
    @endif
@endsection
