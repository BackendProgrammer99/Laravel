@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-12">
            <h1 style="margin: 19px;" class="display-2 mt-5">Rezerwacje</h1>

            <div class="text-right">
                <a style="margin: 19px;" href="{{ route('reservations.create') }}" class="btn btn-primary">
                    {{ __('DODAJ REZERWACJE') }}
                </a>
            </div>

            <table class="table table-striped text-center">
                <thead>
                    <tr>
                        <td>Nr</td>
                        <td>Data</td>
                        <td>Godzina od</td>
                        <td>Godzina do</td>
                        <td>Liczba gości</td>
                        <td>Cena</td>
                        <td>Usługa</td>
                        <td>Klient</td>
                        <td>Data utworzenia</td>
                        <td>Data aktualizacji</td>
                        <td>Data usunięcia</td>
                        <td>Edytuj</td>
                        <td>Usuń</td>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($reservations as $reservation)
                        <tr>
                            <td>{{ $reservation->id }}</td>
                            <td>{{ $reservation->data }}</td>
                            <td>{{ $reservation->timefrom }}</td>
                            <td>{{ $reservation->timeto }}</td>
                            <td>{{ $reservation->numberofpeople }}</td>
                            <td>{{ $reservation->endprice }}</td>
                            <td>
                                @if (isset($reservation->service))
                                    {{ $reservation->service->name }}
                                @endif
                            </td>
                            <td>
                                @if (isset($reservation->customer))
                                    {{ $reservation->customer->name }}
                                @endif
                            </td>
                            <td>{{ $reservation->created_at }}</td>
                            <td>{{ $reservation->updated_at }}</td>
                            <td>{{ $reservation->deleted_at }}</td>
                            <td>
                                @if (!isset($reservation->deleted_at))
                                    <a href="{{ route('reservations.edit', $reservation->id) }}" class="btn btn-primary">
                                        {{ __('EDYTUJ') }}
                                    </a>
                                @endif
                            </td>
                            <td>
                                @if (!isset($reservation->deleted_at))
                                    <form action="{{ route('reservations.destroy', $reservation->id) }}" method="post">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-danger" type="submit">
                                            {{ __('USUŃ') }}
                                        </button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
@section('js-scripts')
    <script type="text/javascript" src="{{ url('js/plugins/confirm_destroy.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/external/datatables.min.js') }}"></script>

    <script src="{{ asset('js/app.js') }}" defer></script>

@endsection
