<div class="modal fade" id="confirm-destroy-modal"
        tabindex="-1" role="dialog"
        aria-labelledby="confirm-destroy-modal-title" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="confirm-destroy-modal-form"
                action="" method="POST">
                @method('DELETE')
                @csrf
                <div class="modal-header">
                    <h4 class="modal-title" id="confirm-destroy-modal-title"></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                </div>
                <div class="modal-body">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">{{ __('translation.buttons.cancel') }}</button>
                    <button type="submit" class="btn btn-danger">{{ __('translation.buttons.confirm') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>