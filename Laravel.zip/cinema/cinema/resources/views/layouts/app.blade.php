<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    {{-- CSRF Token --}}
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    {{-- Styles --}}
    {{-- Bootstrap i Font-Awesome --}}
    <link href="{{ url('css/external/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ url('css/external/font-awesome-all.min.css') }}" type="text/css" rel="stylesheet">
    {{-- Globalne CSSy użytkownika --}}
    <link href="{{ url('css/all.min.css') }}" rel="stylesheet">
    <link href="{{ url('resources/css/app.css') }}" rel="stylesheet">
    {{-- Lokalne style CSS --}}
    @yield('css-styles')
</head>

<body>
    {{-- @include('layouts.alert') --}}
    {{-- Navbar --}}
    @include('layouts.navbar')

    {{-- Głowny kontener --}}
    <main role="main" class="container padding-top-content">
        @include('layouts.alert')
        @yield('content')
    </main>
    @include('layouts.footer')
</body>
{{-- JQuery Pooper Bootstrap --}}
<script type="text/javascript" src="{{ url('js/external/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ url('js/external/popper.min.js') }}"></script>
<script type="text/javascript" src="{{ url('js/external/bootstrap.min.js') }}"></script>
{{-- Funkcja debugująca --}}
{{-- Funkcja do debugowania JS --}}
@if (config('app.env') === 'dev')
    <script type="text/javascript">
        var d = function(message) {
            console.log(message);
        }
    </script>
@else
    <script type="text/javascript">
        var d = function(message) {}
    </script>
@endif
{{-- Globalne skrypty użytkownika --}}
<script type="text/javascript" src="{{ url(mix('js/all.min.js')) }}"></script>
{{-- Lokalne skrypty JS --}}
@yield('js-scripts')

</html>
