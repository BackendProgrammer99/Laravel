(function($) {
    $.fn.ConfirmDestroy = function(extendDefaultOptions) {
        /**
         * Domyślna konfiguracja wtyczki
         */
        let settings = $.extend({
            dataUrl: 'url', // adres na który ma być przekierowany formularz (data-url)
            dataTitle: 'title', // przedrostek tytułu okna modalnego (data-title)
            dataMessage: 'message', // przedrostek treście okna modalnego (data-message)

            selectorContent : '.modal-body', //miejsce załadowania treści formularza
            selectorModal : '#confirm-destroy-modal',       //selektor okna modalnego z formularzem
        }, extendDefaultOptions );

        return this.each(function() {
            let selected = this;
            $(selected).on('click', function() {
                if(typeof $(this).attr('data-' + settings.dataUrl) != undefined) {
                    let path = $(this).attr('data-' + settings.dataUrl);

                    $(settings.selectorModal + '-form').attr('action', path);
                    $(settings.selectorModal + "-title")
                        .html($(this).attr('data-' + settings.dataTitle));
                    $(settings.selectorModal + " " + settings.selectorContent)
                        .html($(this).attr('data-' + settings.dataMessage));
                    $(settings.selectorModal).modal(settings.modalEvent);
                }
            });
        });
    }
})(jQuery);
